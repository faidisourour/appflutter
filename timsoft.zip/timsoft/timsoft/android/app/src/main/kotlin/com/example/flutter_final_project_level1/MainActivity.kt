package com.example.flutter_final_project_level1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
